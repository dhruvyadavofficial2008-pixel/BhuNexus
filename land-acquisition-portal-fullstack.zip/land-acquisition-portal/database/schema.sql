-- Reference PostgreSQL schema for a production migration.
-- The runnable prototype uses a zero-dependency local JSON store instead.

CREATE TABLE users (
  id UUID PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK (role IN ('citizen', 'admin')),
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE projects (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  district TEXT NOT NULL,
  progress INTEGER NOT NULL CHECK (progress BETWEEN 0 AND 100),
  status TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE parcels (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(id),
  owner_id UUID REFERENCES users(id),
  owner_name TEXT NOT NULL,
  village TEXT NOT NULL,
  area_acres NUMERIC(8, 3) NOT NULL,
  status TEXT NOT NULL,
  current_stage TEXT NOT NULL,
  compensation_due NUMERIC(14, 2) NOT NULL,
  compensation_paid NUMERIC(14, 2) NOT NULL,
  last_updated TIMESTAMPTZ NOT NULL
);

CREATE TABLE documents (
  id UUID PRIMARY KEY,
  parcel_id TEXT NOT NULL REFERENCES parcels(id),
  owner_id UUID NOT NULL REFERENCES users(id),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  status TEXT NOT NULL,
  storage_key TEXT,
  uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE grievances (
  id UUID PRIMARY KEY,
  parcel_id TEXT NOT NULL REFERENCES parcels(id),
  user_id UUID NOT NULL REFERENCES users(id),
  subject TEXT NOT NULL,
  message TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
