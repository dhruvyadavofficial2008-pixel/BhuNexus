const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_DIR = path.join(ROOT, 'data');
const DATA_FILE = path.join(DATA_DIR, 'portal-data.json');
const UPLOAD_DIR = path.join(ROOT, 'uploads');
const MAX_BODY_BYTES = 3 * 1024 * 1024;
const SESSION_TTL_MS = 24 * 60 * 60 * 1000;
const sessions = new Map();

const MIME_TYPES = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.ico': 'image/x-icon',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.pdf': 'application/pdf',
  '.png': 'image/png',
  '.svg': 'image/svg+xml; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8'
};

function ensureDirectories() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

function now() {
  return new Date().toISOString();
}

function id(prefix) {
  return `${prefix}-${crypto.randomUUID()}`;
}

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function createUser({ id: userId = id('usr'), name, email, role = 'citizen', password }) {
  const salt = crypto.randomBytes(16).toString('hex');
  return {
    id: userId,
    name,
    email: email.toLowerCase(),
    role,
    passwordSalt: salt,
    passwordHash: hashPassword(password, salt),
    createdAt: now()
  };
}

function createDefaultStore() {
  const citizen = createUser({
    id: 'usr-citizen-demo',
    name: 'Aarav Mehta',
    email: 'citizen@demo.gov',
    role: 'citizen',
    password: 'Citizen@123'
  });
  const admin = createUser({
    id: 'usr-admin-demo',
    name: 'Priya Nair',
    email: 'admin@demo.gov',
    role: 'admin',
    password: 'Admin@123'
  });

  return {
    users: [citizen, admin],
    projects: [
      {
        id: 'PRJ-07',
        name: 'East Connector Mobility Corridor',
        district: 'Riverview District',
        status: 'On track',
        progress: 64,
        parcels: 128,
        updatedAt: '2026-09-05T08:30:00.000Z'
      },
      {
        id: 'PRJ-11',
        name: 'Community Water Resilience Works',
        district: 'Northfield District',
        status: 'Needs review',
        progress: 42,
        parcels: 76,
        updatedAt: '2026-09-04T13:45:00.000Z'
      },
      {
        id: 'PRJ-15',
        name: 'Regional Health Access Link',
        district: 'Lakeview District',
        status: 'On track',
        progress: 81,
        parcels: 54,
        updatedAt: '2026-09-03T10:05:00.000Z'
      }
    ],
    parcels: [
      {
        id: 'PAR-2026-014A',
        projectId: 'PRJ-07',
        ownerId: citizen.id,
        ownerName: 'Aarav Mehta',
        village: 'Kalyanpur',
        surveyNo: '42/7A',
        areaAcres: 1.24,
        status: 'Verification in progress',
        currentStage: 'Verify',
        compensationDue: 1840000,
        compensationPaid: 920000,
        lastUpdated: '2026-09-05T08:30:00.000Z',
        map: { x: 96, y: 68, width: 130, height: 86, color: '#d97706' },
        timeline: [
          { stage: 'Identify', date: '12 Jun 2026', state: 'complete', note: 'Parcel identified in project boundary.' },
          { stage: 'Survey', date: '18 Jun 2026', state: 'complete', note: 'Joint survey recorded.' },
          { stage: 'Notify', date: '02 Jul 2026', state: 'complete', note: 'Initial notice issued.' },
          { stage: 'Verify', date: 'In progress', state: 'active', note: 'Ownership documents under verification.' },
          { stage: 'Acquire', date: 'Pending', state: 'upcoming', note: 'Awaiting verification closure.' },
          { stage: 'Compensate', date: 'Partial', state: 'upcoming', note: 'First payment released.' },
          { stage: 'Monitor', date: 'Pending', state: 'upcoming', note: 'Post-acquisition monitoring.' }
        ]
      },
      {
        id: 'PAR-2026-021C',
        projectId: 'PRJ-07',
        ownerId: 'usr-synthetic-01',
        ownerName: 'Synthetic Demo Holder',
        village: 'Kalyanpur',
        surveyNo: '43/1C',
        areaAcres: 0.86,
        status: 'Compensation processing',
        currentStage: 'Compensate',
        compensationDue: 1260000,
        compensationPaid: 0,
        lastUpdated: '2026-09-04T09:20:00.000Z',
        map: { x: 244, y: 68, width: 116, height: 86, color: '#0f766e' },
        timeline: [
          { stage: 'Identify', date: '03 May 2026', state: 'complete', note: 'Parcel identified.' },
          { stage: 'Survey', date: '09 May 2026', state: 'complete', note: 'Survey completed.' },
          { stage: 'Notify', date: '28 May 2026', state: 'complete', note: 'Notice issued.' },
          { stage: 'Verify', date: '16 Jun 2026', state: 'complete', note: 'Records verified.' },
          { stage: 'Acquire', date: '10 Jul 2026', state: 'complete', note: 'Award approved.' },
          { stage: 'Compensate', date: 'In progress', state: 'active', note: 'Bank details confirmation pending.' },
          { stage: 'Monitor', date: 'Pending', state: 'upcoming', note: 'Post-payment monitoring.' }
        ]
      },
      {
        id: 'PAR-2026-031B',
        projectId: 'PRJ-11',
        ownerId: 'usr-synthetic-02',
        ownerName: 'Synthetic Demo Holder',
        village: 'Anandgram',
        surveyNo: '18/3B',
        areaAcres: 2.12,
        status: 'Objection received',
        currentStage: 'Notify',
        compensationDue: 2970000,
        compensationPaid: 0,
        lastUpdated: '2026-09-03T14:10:00.000Z',
        map: { x: 382, y: 68, width: 130, height: 86, color: '#b91c1c' },
        timeline: [
          { stage: 'Identify', date: '20 Jul 2026', state: 'complete', note: 'Parcel identified.' },
          { stage: 'Survey', date: '27 Jul 2026', state: 'complete', note: 'Survey completed.' },
          { stage: 'Notify', date: 'In progress', state: 'active', note: 'Objection window remains open.' },
          { stage: 'Verify', date: 'Pending', state: 'upcoming', note: 'Starts after notice resolution.' },
          { stage: 'Acquire', date: 'Pending', state: 'upcoming', note: 'Not started.' },
          { stage: 'Compensate', date: 'Pending', state: 'upcoming', note: 'Not started.' },
          { stage: 'Monitor', date: 'Pending', state: 'upcoming', note: 'Not started.' }
        ]
      },
      {
        id: 'PAR-2026-008D',
        projectId: 'PRJ-15',
        ownerId: 'usr-synthetic-03',
        ownerName: 'Synthetic Demo Holder',
        village: 'Bhadra',
        surveyNo: '90/8D',
        areaAcres: 0.64,
        status: 'Monitoring',
        currentStage: 'Monitor',
        compensationDue: 710000,
        compensationPaid: 710000,
        lastUpdated: '2026-08-31T11:45:00.000Z',
        map: { x: 96, y: 172, width: 130, height: 86, color: '#2563eb' },
        timeline: [
          { stage: 'Identify', date: '02 Mar 2026', state: 'complete', note: 'Parcel identified.' },
          { stage: 'Survey', date: '08 Mar 2026', state: 'complete', note: 'Survey completed.' },
          { stage: 'Notify', date: '22 Mar 2026', state: 'complete', note: 'Notice issued.' },
          { stage: 'Verify', date: '10 Apr 2026', state: 'complete', note: 'Records verified.' },
          { stage: 'Acquire', date: '07 May 2026', state: 'complete', note: 'Award approved.' },
          { stage: 'Compensate', date: '20 May 2026', state: 'complete', note: 'Payment confirmed.' },
          { stage: 'Monitor', date: 'Active', state: 'active', note: 'Case remains open for monitoring.' }
        ]
      }
    ],
    documents: [
      {
        id: 'doc-001',
        parcelId: 'PAR-2026-014A',
        ownerId: citizen.id,
        name: 'Identity verification.pdf',
        type: 'Identity document',
        status: 'Verified',
        uploadedAt: '2026-08-22T10:00:00.000Z'
      },
      {
        id: 'doc-002',
        parcelId: 'PAR-2026-014A',
        ownerId: citizen.id,
        name: 'Bank details acknowledgement.pdf',
        type: 'Bank details',
        status: 'Under verification',
        uploadedAt: '2026-09-01T09:15:00.000Z'
      }
    ],
    grievances: [
      {
        id: 'GRV-1048',
        parcelId: 'PAR-2026-014A',
        userId: citizen.id,
        subject: 'Clarification on remaining compensation',
        message: 'Please confirm the expected processing date for the remaining amount.',
        status: 'In review',
        createdAt: '2026-09-02T08:00:00.000Z'
      }
    ],
    notifications: [
      {
        id: 'note-001',
        userId: citizen.id,
        title: 'Verification update',
        body: 'Your parcel record has moved to ownership verification.',
        type: 'info',
        read: false,
        createdAt: '2026-09-05T08:30:00.000Z'
      },
      {
        id: 'note-002',
        userId: citizen.id,
        title: 'Payment released',
        body: 'A partial compensation payment is recorded in this prototype.',
        type: 'success',
        read: true,
        createdAt: '2026-08-28T11:40:00.000Z'
      },
      {
        id: 'note-admin-001',
        userId: admin.id,
        title: 'Attention required',
        body: 'One synthetic project has a high-risk decision support score.',
        type: 'warning',
        read: false,
        createdAt: '2026-09-05T07:55:00.000Z'
      }
    ]
  };
}

function loadStore() {
  ensureDirectories();
  if (!fs.existsSync(DATA_FILE)) {
    const initialStore = createDefaultStore();
    saveStore(initialStore);
    return initialStore;
  }
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch (error) {
    throw new Error(`The local data store could not be read: ${error.message}`);
  }
}

function saveStore(store) {
  ensureDirectories();
  const temporaryFile = `${DATA_FILE}.tmp`;
  fs.writeFileSync(temporaryFile, JSON.stringify(store, null, 2), 'utf8');
  fs.renameSync(temporaryFile, DATA_FILE);
}

let store = loadStore();

function safeUser(user) {
  return { id: user.id, name: user.name, email: user.email, role: user.role, createdAt: user.createdAt };
}

function getToken(req) {
  const header = req.headers.authorization || '';
  return header.startsWith('Bearer ') ? header.slice(7) : null;
}

function getCurrentUser(req) {
  const token = getToken(req);
  const session = token ? sessions.get(token) : null;
  if (!session || session.expiresAt < Date.now()) {
    if (token) sessions.delete(token);
    return null;
  }
  return store.users.find((user) => user.id === session.userId) || null;
}

function createSession(user) {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { userId: user.id, expiresAt: Date.now() + SESSION_TTL_MS });
  return token;
}

function verifyPassword(password, user) {
  const candidate = Buffer.from(hashPassword(password, user.passwordSalt), 'hex');
  const actual = Buffer.from(user.passwordHash, 'hex');
  return candidate.length === actual.length && crypto.timingSafeEqual(candidate, actual);
}

function sendJson(res, statusCode, payload) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  res.end(JSON.stringify(payload));
}

function sendError(res, statusCode, message) {
  sendJson(res, statusCode, { error: message });
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(new Error('Request body exceeds the 3 MB demo limit.'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {});
      } catch {
        reject(new Error('Request body must contain valid JSON.'));
      }
    });
    req.on('error', reject);
  });
}

function requireUser(req, res) {
  const user = getCurrentUser(req);
  if (!user) {
    sendError(res, 401, 'Please sign in to continue.');
    return null;
  }
  return user;
}

function requireAdmin(req, res) {
  const user = requireUser(req, res);
  if (!user) return null;
  if (user.role !== 'admin') {
    sendError(res, 403, 'This action is available to an authorised administrator only.');
    return null;
  }
  return user;
}

function canAccessParcel(user, parcel) {
  return Boolean(user && (user.role === 'admin' || parcel.ownerId === user.id));
}

function parcelView(parcel, viewer) {
  const isAuthorised = canAccessParcel(viewer, parcel);
  return {
    ...parcel,
    ownerName: isAuthorised ? parcel.ownerName : 'Protected landholder',
    compensationDue: isAuthorised ? parcel.compensationDue : null,
    compensationPaid: isAuthorised ? parcel.compensationPaid : null,
    timeline: isAuthorised ? parcel.timeline : parcel.timeline.map((item) => ({ stage: item.stage, state: item.state }))
  };
}

function makeDashboard(viewer, parcels) {
  const active = parcels.filter((parcel) => !['Monitoring'].includes(parcel.status));
  const pendingCompensation = parcels.reduce((total, parcel) => total + Math.max(0, parcel.compensationDue - parcel.compensationPaid), 0);
  const openGrievances = store.grievances.filter((item) => viewer.role === 'admin' || item.userId === viewer.id).filter((item) => item.status !== 'Resolved').length;
  return {
    activeCases: active.length,
    verificationCases: parcels.filter((parcel) => parcel.currentStage === 'Verify').length,
    pendingCompensation,
    openGrievances,
    projectsOnTrack: store.projects.filter((project) => project.status === 'On track').length
  };
}

function riskAssessment(input) {
  const disputes = Math.max(0, Number(input.disputes) || 0);
  const pendingCompensation = Math.max(0, Number(input.pendingCompensation) || 0);
  const delayDays = Math.max(0, Number(input.delayDays) || 0);
  const affectedLandowners = Math.max(0, Number(input.affectedLandowners) || 0);
  const pendingDocuments = Math.max(0, Number(input.pendingDocuments) || 0);
  const score = Math.round((disputes * 5 + pendingCompensation * 2 + delayDays * 0.5) * 10) / 10;
  const level = score >= 30 ? 'High' : score >= 12 ? 'Medium' : 'Low';
  const recommendation = level === 'High'
    ? 'Prioritise dispute resolution and compensation verification before advancing the case.'
    : level === 'Medium'
      ? 'Assign a case review and confirm outstanding documents within the next review cycle.'
      : 'Continue routine monitoring and publish the next status update on schedule.';
  return {
    inputs: { disputes, pendingCompensation, delayDays, affectedLandowners, pendingDocuments },
    score,
    level,
    formula: 'Risk score = (disputes x 5) + (pending compensation cases x 2) + (delay days x 0.5)',
    recommendation,
    disclaimer: 'Decision-support output only. It is a transparent prototype rule, not an automated decision.'
  };
}

function addNotification(userId, title, body, type = 'info') {
  const notification = { id: id('note'), userId, title, body, type, read: false, createdAt: now() };
  store.notifications.unshift(notification);
  return notification;
}

function routePath(req) {
  return new URL(req.url, `http://${req.headers.host || 'localhost'}`).pathname;
}

function serveStatic(req, res, pathname) {
  const requested = pathname === '/' ? '/index.html' : pathname;
  const decoded = decodeURIComponent(requested);
  const filePath = path.resolve(PUBLIC_DIR, `.${decoded}`);
  if (!filePath.startsWith(PUBLIC_DIR) || !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    sendError(res, 404, 'Page not found.');
    return;
  }
  const extension = path.extname(filePath).toLowerCase();
  res.writeHead(200, {
    'Content-Type': MIME_TYPES[extension] || 'application/octet-stream',
    'X-Content-Type-Options': 'nosniff',
    'Cache-Control': extension === '.html' ? 'no-cache' : 'public, max-age=3600'
  });
  fs.createReadStream(filePath).pipe(res);
}

async function handleApi(req, res, pathname) {
  const method = req.method;
  if (method === 'GET' && pathname === '/api/health') {
    sendJson(res, 200, { status: 'ok', service: 'land-acquisition-portal', timestamp: now() });
    return;
  }

  if (method === 'POST' && pathname === '/api/auth/login') {
    const body = await readJson(req);
    const email = String(body.email || '').trim().toLowerCase();
    const user = store.users.find((entry) => entry.email === email);
    if (!user || !verifyPassword(String(body.password || ''), user)) {
      sendError(res, 401, 'The email address or password is not recognised.');
      return;
    }
    const token = createSession(user);
    sendJson(res, 200, { token, user: safeUser(user) });
    return;
  }

  if (method === 'POST' && pathname === '/api/auth/register') {
    const body = await readJson(req);
    const name = String(body.name || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    if (name.length < 2 || name.length > 80) return sendError(res, 400, 'Enter a name between 2 and 80 characters.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return sendError(res, 400, 'Enter a valid email address.');
    if (password.length < 10) return sendError(res, 400, 'Use a password of at least 10 characters.');
    if (store.users.some((entry) => entry.email === email)) return sendError(res, 409, 'An account already exists for that email address.');
    const user = createUser({ name, email, password });
    store.users.push(user);
    addNotification(user.id, 'Welcome to the prototype', 'Your citizen portal is ready. Choose a parcel to view its demonstration workflow.', 'success');
    saveStore(store);
    sendJson(res, 201, { token: createSession(user), user: safeUser(user) });
    return;
  }

  if (method === 'POST' && pathname === '/api/auth/logout') {
    const token = getToken(req);
    if (token) sessions.delete(token);
    sendJson(res, 200, { message: 'Signed out.' });
    return;
  }

  if (method === 'GET' && pathname === '/api/bootstrap') {
    const user = getCurrentUser(req);
    const visibleParcels = user?.role === 'citizen' ? store.parcels.filter((parcel) => parcel.ownerId === user.id) : store.parcels;
    const parcels = visibleParcels.map((parcel) => parcelView(parcel, user));
    const documents = user ? store.documents.filter((document) => user.role === 'admin' || document.ownerId === user.id) : [];
    const grievances = user ? store.grievances.filter((item) => user.role === 'admin' || item.userId === user.id) : [];
    const notifications = user ? store.notifications.filter((item) => item.userId === user.id).slice(0, 5) : [];
    sendJson(res, 200, {
      user: user ? safeUser(user) : null,
      demoNotice: 'Synthetic demonstration data. This prototype is not connected to official government land records.',
      projects: store.projects,
      parcels,
      documents,
      grievances,
      notifications,
      dashboard: user ? makeDashboard(user, visibleParcels) : null
    });
    return;
  }

  if (method === 'GET' && pathname.startsWith('/api/parcels/')) {
    const parcelId = decodeURIComponent(pathname.slice('/api/parcels/'.length));
    const parcel = store.parcels.find((item) => item.id === parcelId);
    if (!parcel) return sendError(res, 404, 'Parcel not found.');
    const viewer = getCurrentUser(req);
    sendJson(res, 200, { parcel: parcelView(parcel, viewer), project: store.projects.find((project) => project.id === parcel.projectId) });
    return;
  }

  if (method === 'GET' && pathname === '/api/documents') {
    const user = requireUser(req, res);
    if (!user) return;
    sendJson(res, 200, { documents: store.documents.filter((document) => user.role === 'admin' || document.ownerId === user.id) });
    return;
  }

  if (method === 'POST' && pathname === '/api/documents') {
    const user = requireUser(req, res);
    if (!user) return;
    const body = await readJson(req);
    const parcel = store.parcels.find((item) => item.id === body.parcelId);
    if (!parcel) return sendError(res, 404, 'Choose a valid parcel.');
    if (!canAccessParcel(user, parcel)) return sendError(res, 403, 'You can only upload documents for your own case.');
    const name = String(body.name || '').replace(/[^a-zA-Z0-9._ -]/g, '_').slice(0, 100);
    const type = String(body.type || 'Supporting document').slice(0, 80);
    const dataUrl = String(body.dataUrl || '');
    if (!name || !dataUrl.startsWith('data:')) return sendError(res, 400, 'Select a file to upload.');
    const match = dataUrl.match(/^data:([a-zA-Z0-9/+.-]+);base64,([A-Za-z0-9+/=]+)$/);
    if (!match) return sendError(res, 400, 'The file format could not be processed.');
    const data = Buffer.from(match[2], 'base64');
    if (data.length === 0 || data.length > 2 * 1024 * 1024) return sendError(res, 400, 'Use a file smaller than 2 MB for this prototype.');
    const documentId = id('doc');
    const storageKey = `${documentId}-${name}`;
    fs.writeFileSync(path.join(UPLOAD_DIR, storageKey), data);
    const document = { id: documentId, parcelId: parcel.id, ownerId: user.id, name, type, status: 'Received - under verification', storageKey, uploadedAt: now() };
    store.documents.unshift(document);
    addNotification(user.id, 'Document received', `${name} is recorded and awaiting verification.`, 'info');
    saveStore(store);
    sendJson(res, 201, { document, message: 'Document received for verification.' });
    return;
  }

  if (method === 'POST' && pathname === '/api/grievances') {
    const user = requireUser(req, res);
    if (!user) return;
    const body = await readJson(req);
    const parcel = store.parcels.find((item) => item.id === body.parcelId);
    const subject = String(body.subject || '').trim();
    const message = String(body.message || '').trim();
    if (!parcel || !canAccessParcel(user, parcel)) return sendError(res, 400, 'Choose one of your active parcels.');
    if (subject.length < 5 || subject.length > 120 || message.length < 15 || message.length > 2000) return sendError(res, 400, 'Provide a concise subject and a message of 15 to 2,000 characters.');
    const grievance = { id: `GRV-${String(Date.now()).slice(-6)}`, parcelId: parcel.id, userId: user.id, subject, message, status: 'Submitted', createdAt: now() };
    store.grievances.unshift(grievance);
    addNotification(user.id, 'Grievance submitted', `${grievance.id} was received and is ready for review.`, 'success');
    saveStore(store);
    sendJson(res, 201, { grievance, message: `Your reference is ${grievance.id}.` });
    return;
  }

  if (method === 'GET' && pathname === '/api/admin/summary') {
    const user = requireAdmin(req, res);
    if (!user) return;
    sendJson(res, 200, { dashboard: makeDashboard(user, store.parcels), projects: store.projects, recentGrievances: store.grievances.slice(0, 5) });
    return;
  }

  if (method === 'POST' && pathname === '/api/risk/analyze') {
    const user = requireAdmin(req, res);
    if (!user) return;
    const body = await readJson(req);
    sendJson(res, 200, { analysis: riskAssessment(body) });
    return;
  }

  if (method === 'POST' && /^\/api\/notifications\/[^/]+\/read$/.test(pathname)) {
    const user = requireUser(req, res);
    if (!user) return;
    const notificationId = decodeURIComponent(pathname.split('/')[3]);
    const notification = store.notifications.find((item) => item.id === notificationId && item.userId === user.id);
    if (!notification) return sendError(res, 404, 'Notification not found.');
    notification.read = true;
    saveStore(store);
    sendJson(res, 200, { notification });
    return;
  }

  sendError(res, 404, 'API endpoint not found.');
}

const server = http.createServer(async (req, res) => {
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'self'; form-action 'self'");
  const pathname = routePath(req);
  try {
    if (pathname.startsWith('/api/')) {
      await handleApi(req, res, pathname);
    } else if (req.method === 'GET' || req.method === 'HEAD') {
      serveStatic(req, res, pathname);
    } else {
      sendError(res, 405, 'Method not allowed.');
    }
  } catch (error) {
    console.error(error);
    if (!res.headersSent) sendError(res, 500, 'The service could not complete that request.');
    else res.end();
  }
});

server.listen(PORT, () => {
  console.log(`Land Acquisition Portal is running at http://localhost:${PORT}`);
});
