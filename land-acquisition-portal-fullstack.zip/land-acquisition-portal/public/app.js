(() => {
  'use strict';

  const $ = (selector, parent = document) => parent.querySelector(selector);
  const $$ = (selector, parent = document) => [...parent.querySelectorAll(selector)];
  const state = {
    token: localStorage.getItem('nlams-demo-token') || '',
    data: null,
    selectedId: null,
    selectedParcel: null,
    fontSize: Number(localStorage.getItem('nlams-font-size') || 16)
  };

  const currency = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 });
  const svgNS = 'http://www.w3.org/2000/svg';

  function escapeHtml(value = '') {
    return String(value)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function text(id, value) {
    const node = typeof id === 'string' ? document.getElementById(id) : id;
    if (node) node.textContent = value;
  }

  function formatCurrency(value) {
    return typeof value === 'number' ? currency.format(value) : 'Protected';
  }

  function formatDate(value) {
    if (!value) return '';
    const date = new Date(value);
    return Number.isNaN(date.valueOf()) ? '' : date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  }

  function badgeClass(status = '') {
    const normalised = status.toLowerCase();
    if (normalised.includes('objection') || normalised.includes('high')) return 'badge-danger';
    if (normalised.includes('progress') || normalised.includes('review') || normalised.includes('pending') || normalised.includes('partial') || normalised.includes('submitted')) return 'badge-warning';
    if (normalised.includes('monitor') || normalised.includes('track') || normalised.includes('verified') || normalised.includes('resolved')) return 'badge-success';
    return 'badge-info';
  }

  async function api(endpoint, options = {}) {
    const headers = { Accept: 'application/json', ...(options.headers || {}) };
    if (state.token) headers.Authorization = `Bearer ${state.token}`;
    if (options.body && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
    const response = await fetch(endpoint, { ...options, headers });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || 'The service could not complete that request.');
    return payload;
  }

  function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    const copy = document.createElement('span');
    copy.textContent = message;
    const dismiss = document.createElement('button');
    dismiss.type = 'button';
    dismiss.setAttribute('aria-label', 'Dismiss message');
    dismiss.textContent = '×';
    dismiss.addEventListener('click', () => toast.remove());
    toast.append(copy, dismiss);
    $('#toast-region').append(toast);
    window.setTimeout(() => toast.remove(), 5500);
  }

  function setBusy(button, busy, label) {
    if (!button) return;
    if (busy) {
      button.dataset.label = button.textContent;
      button.disabled = true;
      button.textContent = label || 'Working…';
    } else {
      button.disabled = false;
      button.textContent = button.dataset.label || button.textContent;
    }
  }

  function setFontSize(size) {
    state.fontSize = Math.max(14, Math.min(20, size));
    document.documentElement.style.fontSize = `${state.fontSize}px`;
    localStorage.setItem('nlams-font-size', String(state.fontSize));
  }

  function currentUser() {
    return state.data?.user || null;
  }

  function currentParcel() {
    if (state.selectedParcel?.id === state.selectedId) return state.selectedParcel;
    return state.data?.parcels.find((parcel) => parcel.id === state.selectedId) || null;
  }

  async function loadData({ preserveSelection = true } = {}) {
    const previousSelection = preserveSelection ? state.selectedId : null;
    const data = await api('/api/bootstrap');
    state.data = data;
    if (!data.user && state.token) {
      state.token = '';
      localStorage.removeItem('nlams-demo-token');
    }
    const canKeepSelection = data.parcels.some((parcel) => parcel.id === previousSelection);
    state.selectedId = canKeepSelection ? previousSelection : (data.parcels[0]?.id || null);
    state.selectedParcel = data.parcels.find((parcel) => parcel.id === state.selectedId) || null;
    renderAll();
    if (state.selectedId) await selectParcel(state.selectedId, { scroll: false, quiet: true });
  }

  function renderAll() {
    renderAccount();
    renderDashboard();
    renderMap();
    renderParcel();
    renderTimeline();
    renderSupport();
    renderAdmin();
  }

  function renderAccount() {
    const user = currentUser();
    const authTrigger = $('#auth-trigger');
    const chip = $('#user-chip');
    const commandLink = $('.admin-only');
    if (user) {
      authTrigger.textContent = 'Sign out';
      chip.hidden = false;
      chip.textContent = `${user.name} · ${user.role === 'admin' ? 'Administrator' : 'Citizen'}`;
      commandLink.hidden = user.role !== 'admin';
    } else {
      authTrigger.textContent = 'Sign in';
      chip.hidden = true;
      commandLink.hidden = true;
    }
  }

  function renderDashboard() {
    const user = currentUser();
    const dashboard = state.data?.dashboard;
    const panel = $('#notification-panel');
    text('hero-project-count', String(state.data?.projects.length || 0));
    if (!user || !dashboard) {
      text('dashboard-description', 'Sign in to view your case information. You can still explore the anonymised map below.');
      text('stat-active', '—'); text('stat-verify', '—'); text('stat-compensation', '—'); text('stat-grievances', '—');
      panel.hidden = true;
      return;
    }
    text('dashboard-description', user.role === 'admin'
      ? 'Portfolio totals are derived from the synthetic demonstration records. Use the command centre for a transparent risk review.'
      : `Welcome back, ${user.name.split(' ')[0]}. Select your case below for documents, compensation and support.`);
    text('stat-active', String(dashboard.activeCases));
    text('stat-verify', String(dashboard.verificationCases));
    text('stat-compensation', formatCurrency(dashboard.pendingCompensation));
    text('stat-grievances', String(dashboard.openGrievances));
    renderNotifications();
  }

  function renderNotifications() {
    const notes = state.data?.notifications || [];
    const list = $('#notification-list');
    const panel = $('#notification-panel');
    panel.hidden = false;
    text('unread-count', `${notes.filter((note) => !note.read).length} unread`);
    list.innerHTML = notes.length
      ? notes.map((note) => `<li class="notification-item ${escapeHtml(note.type)}"><strong>${escapeHtml(note.title)}</strong><span>${escapeHtml(note.body)}</span>${note.read ? '' : `<button type="button" data-read-notification="${escapeHtml(note.id)}">Mark as read</button>`}</li>`).join('')
      : '<li class="empty-state">There are no recent service notifications.</li>';
  }

  function makeSvgNode(name, attributes = {}) {
    const node = document.createElementNS(svgNS, name);
    Object.entries(attributes).forEach(([key, value]) => node.setAttribute(key, value));
    return node;
  }

  function renderMap() {
    const mapGroup = $('#map-parcels');
    mapGroup.replaceChildren();
    for (const parcel of state.data?.parcels || []) {
      const group = makeSvgNode('g', {
        class: `parcel-shape${parcel.id === state.selectedId ? ' selected' : ''}`,
        role: 'button',
        tabindex: '0',
        'aria-label': `${parcel.id}, ${parcel.status}. Select to view case summary.`,
        'data-parcel-id': parcel.id
      });
      const title = makeSvgNode('title');
      title.textContent = `${parcel.id}: ${parcel.status}`;
      const shape = makeSvgNode('rect', { x: parcel.map.x, y: parcel.map.y, width: parcel.map.width, height: parcel.map.height, rx: '5', fill: parcel.map.color, stroke: '#ffffff', 'stroke-width': '2' });
      const reference = makeSvgNode('text', { x: parcel.map.x + parcel.map.width / 2, y: parcel.map.y + parcel.map.height / 2 - 5 });
      reference.textContent = parcel.id.replace('PAR-2026-', 'P-');
      const status = makeSvgNode('text', { x: parcel.map.x + parcel.map.width / 2, y: parcel.map.y + parcel.map.height / 2 + 14, opacity: '.86', 'font-size': '9' });
      status.textContent = parcel.currentStage;
      group.append(title, shape, reference, status);
      group.addEventListener('click', () => selectParcel(parcel.id, { scroll: false }));
      group.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          selectParcel(parcel.id, { scroll: false });
        }
      });
      mapGroup.append(group);
    }
  }

  function renderParcel() {
    const parcel = currentParcel();
    const viewButton = $('#view-case-button');
    const copyButton = $('#copy-parcel-button');
    if (!parcel) {
      text('parcel-panel-title', 'No parcel selected');
      text('parcel-location', 'Select a parcel on the map to view the demonstration case summary.');
      $('#parcel-meta').innerHTML = '';
      $('#parcel-status-badge').className = 'badge badge-neutral';
      text('parcel-status-badge', 'Choose a parcel');
      viewButton.disabled = true; copyButton.disabled = true;
      return;
    }
    viewButton.disabled = false; copyButton.disabled = false;
    text('parcel-panel-title', parcel.id);
    text('parcel-location', `${parcel.village} · Survey no. ${parcel.surveyNo}`);
    const statusBadge = $('#parcel-status-badge');
    statusBadge.className = `badge ${badgeClass(parcel.status)}`;
    statusBadge.textContent = parcel.status;
    const isProtected = parcel.ownerName === 'Protected landholder';
    $('#parcel-meta').innerHTML = [
      ['Project', parcel.projectId],
      ['Current stage', parcel.currentStage],
      ['Landholder', parcel.ownerName],
      ['Area', isProtected ? 'Protected' : `${parcel.areaAcres} acres`],
      ['Last update', formatDate(parcel.lastUpdated)],
      ['Case status', parcel.status]
    ].map(([label, value]) => `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value)}</dd></div>`).join('');
  }

  function renderTimeline() {
    const parcel = currentParcel();
    const timeline = $('#timeline');
    if (!parcel?.timeline?.length) {
      text('timeline-intro', 'Select a parcel to see its complete timeline.');
      text('case-reference', 'No case selected');
      timeline.innerHTML = '';
      return;
    }
    text('timeline-intro', `Current stage: ${parcel.currentStage}. Each stage below shows the recorded demonstration status.`);
    text('case-reference', parcel.id);
    timeline.innerHTML = parcel.timeline.map((item) => `
      <li class="${escapeHtml(item.state || 'upcoming')}">
        <span class="timeline-stage">${escapeHtml(item.stage)}</span>
        <span class="timeline-date">${escapeHtml(item.date || 'Recorded status')}</span>
        <span class="timeline-note">${escapeHtml(item.note || 'Sign in to see detailed case information.')}</span>
      </li>`).join('');
  }

  function renderSupport() {
    const user = currentUser();
    const parcel = currentParcel();
    const docs = (state.data?.documents || []).filter((document) => !parcel || document.parcelId === parcel.id);
    const grievances = state.data?.grievances || [];
    text('document-count', user ? `${docs.length} ${docs.length === 1 ? 'file' : 'files'}` : 'Sign in');
    $('#document-list').innerHTML = !user
      ? '<li class="empty-state">Sign in to view your submitted documents.</li>'
      : docs.length
        ? docs.map((document) => `<li class="document-item"><div><span class="document-name">${escapeHtml(document.name)}</span><span class="document-meta">${escapeHtml(document.type)} · ${formatDate(document.uploadedAt)}</span></div><span class="badge ${badgeClass(document.status)}">${escapeHtml(document.status)}</span></li>`).join('')
        : '<li class="empty-state">No documents are recorded for the selected case.</li>';

    const hasFinancialData = user && typeof parcel?.compensationDue === 'number';
    if (hasFinancialData) {
      const paid = parcel.compensationPaid;
      const due = parcel.compensationDue;
      const percent = due ? Math.round((paid / due) * 100) : 0;
      text('comp-status', percent === 100 ? 'Recorded as complete' : percent ? 'Partially recorded' : 'Awaiting release');
      $('#comp-status').className = `badge ${percent === 100 ? 'badge-success' : 'badge-warning'}`;
      text('comp-description', `Recorded compensation information for ${parcel.id}.`);
      text('comp-paid', formatCurrency(paid)); text('comp-percent', `${percent}%`); text('comp-total', formatCurrency(due)); text('comp-remaining', formatCurrency(Math.max(0, due - paid)));
      $('#comp-progress').style.width = `${percent}%`;
    } else {
      $('#comp-status').className = 'badge badge-neutral'; text('comp-status', user ? 'Select your case' : 'Sign in');
      text('comp-description', user ? 'Select a case you are authorised to view to show recorded compensation.' : 'Your recorded compensation status appears here after you sign in and select a case.');
      text('comp-paid', '—'); text('comp-percent', '—'); text('comp-total', '—'); text('comp-remaining', '—'); $('#comp-progress').style.width = '0%';
    }

    const shownGrievances = grievances.filter((item) => !parcel || item.parcelId === parcel.id);
    text('grievance-count', user ? `${shownGrievances.filter((item) => item.status !== 'Resolved').length} open` : 'Sign in');
    $('#grievance-list').innerHTML = !user
      ? '<li class="empty-state">Sign in to see grievances linked to your case.</li>'
      : shownGrievances.length
        ? shownGrievances.map((item) => `<li class="grievance-item"><span class="grievance-subject">${escapeHtml(item.subject)}</span><span class="grievance-meta">${escapeHtml(item.id)} · ${formatDate(item.createdAt)}</span><span class="badge ${badgeClass(item.status)}">${escapeHtml(item.status)}</span></li>`).join('')
        : '<li class="empty-state">No grievances are recorded for the selected case.</li>';

    const authForms = $$('.requires-auth');
    authForms.forEach((form) => form.dataset.authenticated = user ? 'true' : 'false');
  }

  function renderAdmin() {
    const user = currentUser();
    const panel = $('#admin-panel');
    const isAdmin = user?.role === 'admin';
    panel.hidden = !isAdmin;
    if (!isAdmin) return;
    const projects = state.data?.projects || [];
    text('on-track-count', `${projects.filter((project) => project.status === 'On track').length} on track`);
    $('#project-list').innerHTML = projects.map((project) => `
      <article class="project-row">
        <div class="project-row-top"><strong>${escapeHtml(project.name)}</strong><span class="badge ${badgeClass(project.status)}">${escapeHtml(project.status)}</span></div>
        <span>${escapeHtml(project.district)} · ${project.parcels} parcels · updated ${formatDate(project.updatedAt)}</span>
        <div class="progress-track" aria-label="${escapeHtml(project.name)} progress ${project.progress}%"><span style="width:${Math.max(0, Math.min(100, project.progress))}%"></span></div>
      </article>`).join('');
  }

  async function selectParcel(parcelId, { scroll = false, quiet = false } = {}) {
    if (!parcelId) return;
    try {
      const response = await api(`/api/parcels/${encodeURIComponent(parcelId)}`);
      state.selectedId = parcelId;
      state.selectedParcel = response.parcel;
      const index = state.data.parcels.findIndex((parcel) => parcel.id === parcelId);
      if (index >= 0) state.data.parcels[index] = response.parcel;
      renderMap(); renderParcel(); renderTimeline(); renderSupport();
      if (scroll) $('#case-tracking').scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (error) {
      if (!quiet) showToast(error.message, 'error');
    }
  }

  function openAuth() {
    const dialog = $('#auth-dialog');
    if (!dialog.open) dialog.showModal();
    window.setTimeout(() => $('#login-email').focus(), 20);
  }

  function closeAuth() {
    const dialog = $('#auth-dialog');
    if (dialog.open) dialog.close();
  }

  function switchAuthTab(tab) {
    const login = tab === 'login';
    $('#login-tab').classList.toggle('active', login); $('#login-tab').setAttribute('aria-selected', String(login));
    $('#register-tab').classList.toggle('active', !login); $('#register-tab').setAttribute('aria-selected', String(!login));
    $('#login-panel').hidden = !login; $('#register-panel').hidden = login;
    window.setTimeout(() => (login ? $('#login-email') : $('#register-name')).focus(), 0);
  }

  async function handleLogin(event) {
    event.preventDefault();
    const button = $('button[type="submit"]', event.currentTarget);
    setBusy(button, true, 'Signing in…');
    try {
      const response = await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: $('#login-email').value, password: $('#login-password').value }) });
      state.token = response.token;
      localStorage.setItem('nlams-demo-token', state.token);
      closeAuth(); await loadData({ preserveSelection: false });
      showToast(`Welcome, ${response.user.name}. Your portal is ready.`, 'success');
    } catch (error) { showToast(error.message, 'error'); }
    finally { setBusy(button, false); }
  }

  async function handleRegister(event) {
    event.preventDefault();
    const button = $('button[type="submit"]', event.currentTarget);
    setBusy(button, true, 'Creating account…');
    try {
      const response = await api('/api/auth/register', { method: 'POST', body: JSON.stringify({ name: $('#register-name').value, email: $('#register-email').value, password: $('#register-password').value }) });
      state.token = response.token;
      localStorage.setItem('nlams-demo-token', state.token);
      closeAuth(); await loadData({ preserveSelection: false });
      showToast(`Account created. Welcome, ${response.user.name}.`, 'success');
    } catch (error) { showToast(error.message, 'error'); }
    finally { setBusy(button, false); }
  }

  async function signOut() {
    try { await api('/api/auth/logout', { method: 'POST' }); } catch { /* Local session may already be unavailable. */ }
    state.token = ''; state.selectedParcel = null; localStorage.removeItem('nlams-demo-token');
    await loadData({ preserveSelection: false });
    showToast('You have been signed out of the prototype.', 'info');
  }

  async function handleDocument(event) {
    event.preventDefault();
    if (!currentUser()) return openAuth();
    const parcel = currentParcel();
    const file = $('#document-file').files[0];
    if (!parcel) return showToast('Select a parcel before submitting a document.', 'error');
    if (!file) return showToast('Select a document to upload.', 'error');
    if (file.size > 2 * 1024 * 1024) return showToast('Use a document smaller than 2 MB for this prototype.', 'error');
    const button = $('button[type="submit"]', event.currentTarget);
    setBusy(button, true, 'Submitting…');
    try {
      const dataUrl = await readFile(file);
      const response = await api('/api/documents', { method: 'POST', body: JSON.stringify({ parcelId: parcel.id, type: $('#document-type').value, name: file.name, dataUrl }) });
      event.currentTarget.reset(); await loadData(); showToast(response.message, 'success');
    } catch (error) { showToast(error.message, 'error'); }
    finally { setBusy(button, false); }
  }

  function readFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error('The selected file could not be read.'));
      reader.readAsDataURL(file);
    });
  }

  async function handleGrievance(event) {
    event.preventDefault();
    if (!currentUser()) return openAuth();
    const parcel = currentParcel();
    if (!parcel) return showToast('Select a parcel before submitting a grievance.', 'error');
    const button = $('button[type="submit"]', event.currentTarget);
    setBusy(button, true, 'Submitting…');
    try {
      const response = await api('/api/grievances', { method: 'POST', body: JSON.stringify({ parcelId: parcel.id, subject: $('#grievance-subject').value, message: $('#grievance-message').value }) });
      event.currentTarget.reset(); await loadData(); showToast(response.message, 'success');
    } catch (error) { showToast(error.message, 'error'); }
    finally { setBusy(button, false); }
  }

  async function handleRisk(event) {
    event.preventDefault();
    const button = $('button[type="submit"]', event.currentTarget);
    setBusy(button, true, 'Analysing…');
    try {
      const response = await api('/api/risk/analyze', { method: 'POST', body: JSON.stringify({
        affectedLandowners: $('#risk-landowners').value,
        disputes: $('#risk-disputes').value,
        pendingCompensation: $('#risk-compensation').value,
        delayDays: $('#risk-delay').value,
        pendingDocuments: $('#risk-documents').value
      }) });
      renderRiskResult(response.analysis);
    } catch (error) { showToast(error.message, 'error'); }
    finally { setBusy(button, false); }
  }

  function renderRiskResult(analysis) {
    const result = $('#risk-result');
    const level = analysis.level.toLowerCase();
    result.className = `risk-result ${level}`;
    result.innerHTML = `<h4>${escapeHtml(analysis.level)} risk - human review recommended</h4><div class="risk-score"><strong>${analysis.score}</strong><span>transparent risk score</span></div><p>${escapeHtml(analysis.recommendation)}</p><p class="risk-formula">${escapeHtml(analysis.formula)}. ${escapeHtml(analysis.disclaimer)}</p>`;
  }

  async function markNotificationRead(notificationId) {
    try {
      await api(`/api/notifications/${encodeURIComponent(notificationId)}/read`, { method: 'POST' });
      await loadData();
    } catch (error) { showToast(error.message, 'error'); }
  }

  async function copyReference() {
    const parcel = currentParcel();
    if (!parcel) return;
    try {
      await navigator.clipboard.writeText(parcel.id);
      showToast(`${parcel.id} copied to your clipboard.`, 'success');
    } catch {
      showToast(`Parcel reference: ${parcel.id}`, 'info');
    }
  }

  function wireEvents() {
    setFontSize(state.fontSize);
    $('#font-decrease').addEventListener('click', () => setFontSize(state.fontSize - 1));
    $('#font-reset').addEventListener('click', () => setFontSize(16));
    $('#font-increase').addEventListener('click', () => setFontSize(state.fontSize + 1));
    const savedContrast = localStorage.getItem('nlams-high-contrast') === 'true';
    document.body.classList.toggle('high-contrast', savedContrast); $('#contrast-toggle').setAttribute('aria-pressed', String(savedContrast));
    $('#contrast-toggle').addEventListener('click', (event) => {
      const enabled = !document.body.classList.contains('high-contrast');
      document.body.classList.toggle('high-contrast', enabled); event.currentTarget.setAttribute('aria-pressed', String(enabled));
      localStorage.setItem('nlams-high-contrast', String(enabled));
    });
    $('#nav-toggle').addEventListener('click', (event) => {
      const navigation = $('#primary-navigation');
      const open = !navigation.classList.contains('open');
      navigation.classList.toggle('open', open); event.currentTarget.setAttribute('aria-expanded', String(open));
    });
    $$('.nav-link').forEach((link) => link.addEventListener('click', () => {
      $$('.nav-link').forEach((item) => item.classList.remove('active')); link.classList.add('active');
      $('#primary-navigation').classList.remove('open'); $('#nav-toggle').setAttribute('aria-expanded', 'false');
    }));
    $('#auth-trigger').addEventListener('click', () => currentUser() ? signOut() : openAuth());
    $$('[data-action="open-auth"]').forEach((button) => button.addEventListener('click', openAuth));
    $('#auth-close').addEventListener('click', closeAuth);
    $('#login-tab').addEventListener('click', () => switchAuthTab('login')); $('#register-tab').addEventListener('click', () => switchAuthTab('register'));
    $('#login-form').addEventListener('submit', handleLogin); $('#register-form').addEventListener('submit', handleRegister);
    $$('.credential-button').forEach((button) => button.addEventListener('click', () => { $('#login-email').value = button.dataset.demoEmail; $('#login-password').value = button.dataset.demoPassword; $('#login-password').focus(); }));
    $('#refresh-data').addEventListener('click', async () => { try { await loadData(); showToast('Status information refreshed.', 'success'); } catch (error) { showToast(error.message, 'error'); } });
    $('#view-case-button').addEventListener('click', () => selectParcel(state.selectedId, { scroll: true }));
    $('#copy-parcel-button').addEventListener('click', copyReference);
    $('#document-form').addEventListener('submit', handleDocument); $('#grievance-form').addEventListener('submit', handleGrievance); $('#risk-form').addEventListener('submit', handleRisk);
    $('#notification-list').addEventListener('click', (event) => { const button = event.target.closest('[data-read-notification]'); if (button) markNotificationRead(button.dataset.readNotification); });
    $('#parcel-search').addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') return;
      event.preventDefault();
      const query = event.currentTarget.value.trim().toLowerCase();
      const match = state.data?.parcels.find((parcel) => parcel.id.toLowerCase() === query || parcel.id.toLowerCase().includes(query));
      if (match) selectParcel(match.id, { scroll: false });
      else showToast('No demonstration parcel matches that reference.', 'error');
    });
  }

  async function start() {
    wireEvents();
    try {
      await loadData({ preserveSelection: false });
    } catch (error) {
      showToast(error.message || 'Could not connect to the local portal service.', 'error');
    }
  }

  start();
})();
