# National Land Acquisition & Management System

An accessible, full-stack prototype for tracking land acquisition cases. It is built with Node.js and browser-native HTML, CSS, and JavaScript - no PHP or external runtime dependencies required.

> **Prototype notice:** All names, parcel records, payment figures, and notifications are synthetic demonstration data. This tool is a proposed monitoring and decision-support layer, not an official government land-record system.

## What is included

- Citizen registration and sign-in
- Role-aware citizen portal and admin command centre
- Clickable schematic parcel map, parcel detail panel, and seven-step acquisition timeline
- Compensation status, document upload metadata, grievance submission, and notifications
- Transparent risk analysis using the published scoring model
- Persistent local JSON data store, REST API, password hashing, and token-based demo sessions
- Keyboard navigation, skip link, visible focus states, font-size controls, and high-contrast mode

## Run locally

1. Install [Node.js 18+](https://nodejs.org/).
2. Open a terminal in this directory.
3. Run `npm start`.
4. Visit `http://localhost:3000`.

No `npm install` is necessary because the server uses only Node's built-in modules.

## Demo credentials

| Role | Email | Password |
| --- | --- | --- |
| Citizen | citizen@demo.gov | `Citizen@123` |
| Admin | admin@demo.gov | `Admin@123` |

The first start creates `data/portal-data.json`, which stores the local demo data and additions you make. Delete that single file to reset the prototype.

## API overview

| Method | Route | Purpose |
| --- | --- | --- |
| POST | `/api/auth/login` | Start a session |
| POST | `/api/auth/register` | Create a citizen account |
| GET | `/api/bootstrap` | Load role-aware portal data |
| GET | `/api/parcels/:id` | Retrieve a parcel case |
| POST | `/api/documents` | Save document metadata and local file content |
| POST | `/api/grievances` | Submit a grievance |
| POST | `/api/risk/analyze` | Run transparent decision support (admin only) |

## Production considerations

Before real deployment, replace the local data store with an approved database, connect through approved identity and GIS systems, implement server-side audit logging, use a secure session store, add virus scanning for uploads, and complete a security/accessibility review.
